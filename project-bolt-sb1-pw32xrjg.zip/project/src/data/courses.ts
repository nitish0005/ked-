import { Course } from '../types';

export const courses: Course[] = [
  {
    id: '1',
    title: 'Coding Basics: HTML & CSS',
    level: 'Beginner',
    description: 'Learn the fundamentals of web development with HTML and CSS',
    fullDescription: 'Master the building blocks of the web! This comprehensive course covers HTML structure, CSS styling, responsive design, and modern web development practices. Perfect for absolute beginners.',
    instructor: {
      name: 'Sarah Chen',
      bio: 'Senior Web Developer with 8+ years experience teaching coding to beginners',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    duration: '6 weeks',
    modules: [
      'Introduction to HTML',
      'HTML Elements and Structure',
      'CSS Fundamentals',
      'Styling and Layout',
      'Responsive Design',
      'Final Project'
    ],
    category: 'Programming',
    image: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=800',
    enrolled: 1250,
    rating: 4.8
  },
  {
    id: '2',
    title: 'Digital Communication Skills',
    level: 'Beginner',
    description: 'Master professional communication in the digital age',
    fullDescription: 'Develop essential soft skills for the modern workplace. Learn email etiquette, virtual meeting skills, social media professionalism, and effective digital collaboration.',
    instructor: {
      name: 'Michael Rodriguez',
      bio: 'Communications expert and corporate trainer with 10+ years experience',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    duration: '4 weeks',
    modules: [
      'Professional Email Writing',
      'Virtual Meeting Etiquette',
      'Social Media for Professionals',
      'Digital Collaboration Tools',
      'Online Presentation Skills'
    ],
    category: 'Soft Skills',
    image: 'https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg?auto=compress&cs=tinysrgb&w=800',
    enrolled: 890,
    rating: 4.7
  },
  {
    id: '3',
    title: 'Design Thinking for Beginners',
    level: 'Beginner',
    description: 'Learn creative problem-solving through design thinking methodology',
    fullDescription: 'Unlock your creative potential with design thinking! This hands-on course teaches you to approach problems like a designer, focusing on user needs and innovative solutions.',
    instructor: {
      name: 'Emma Thompson',
      bio: 'UX Designer and design thinking facilitator with expertise in human-centered design',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    duration: '5 weeks',
    modules: [
      'Introduction to Design Thinking',
      'Empathy and User Research',
      'Define and Ideate',
      'Prototype and Test',
      'Real-world Application'
    ],
    category: 'Design',
    image: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800',
    enrolled: 675,
    rating: 4.9
  },
  {
    id: '4',
    title: 'Study Skills & Time Management',
    level: 'Beginner',
    description: 'Develop effective study habits and master time management',
    fullDescription: 'Transform your learning with proven study techniques and time management strategies. Perfect for students looking to improve their academic performance and life balance.',
    instructor: {
      name: 'Dr. James Wilson',
      bio: 'Educational psychologist specializing in learning strategies and student success',
      avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    duration: '3 weeks',
    modules: [
      'Active Learning Techniques',
      'Time Management Systems',
      'Note-taking Strategies',
      'Memory and Retention',
      'Exam Preparation'
    ],
    category: 'Study Skills',
    image: 'https://images.pexels.com/photos/159581/dictionary-reference-book-learning-meaning-159581.jpeg?auto=compress&cs=tinysrgb&w=800',
    enrolled: 1100,
    rating: 4.6
  },
  {
    id: '5',
    title: 'Digital Tools for Students',
    level: 'Beginner',
    description: 'Master essential digital tools and productivity apps',
    fullDescription: 'Boost your productivity with essential digital tools every student needs. Learn Google Workspace, note-taking apps, project management tools, and study aids.',
    instructor: {
      name: 'Lisa Park',
      bio: 'Digital literacy instructor helping students maximize their tech potential',
      avatar: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    duration: '4 weeks',
    modules: [
      'Google Workspace Essentials',
      'Note-taking Apps',
      'Project Management Tools',
      'Research and Citation Tools',
      'Study Apps and Extensions'
    ],
    category: 'Digital Tools',
    image: 'https://images.pexels.com/photos/267507/pexels-photo-267507.jpeg?auto=compress&cs=tinysrgb&w=800',
    enrolled: 820,
    rating: 4.5
  },
  {
    id: '6',
    title: 'JavaScript Programming Basics',
    level: 'Beginner',
    description: 'Learn programming fundamentals with JavaScript',
    fullDescription: 'Start your programming journey with JavaScript! Learn variables, functions, loops, and basic programming concepts through interactive exercises and projects.',
    instructor: {
      name: 'Alex Kim',
      bio: 'Full-stack developer and coding bootcamp instructor passionate about teaching',
      avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    duration: '8 weeks',
    modules: [
      'JavaScript Fundamentals',
      'Variables and Data Types',
      'Functions and Scope',
      'Control Structures',
      'DOM Manipulation',
      'Mini Projects'
    ],
    category: 'Programming',
    image: 'https://images.pexels.com/photos/1181673/pexels-photo-1181673.jpeg?auto=compress&cs=tinysrgb&w=800',
    enrolled: 1500,
    rating: 4.9
  }
];