import { UserProgress, Badge, LiveSession, QuizQuestion } from '../types';

export const userProgress: UserProgress[] = [
  { courseId: '1', progress: 75, completed: false, lastAccessed: '2024-01-15' },
  { courseId: '2', progress: 100, completed: true, lastAccessed: '2024-01-10' },
  { courseId: '4', progress: 40, completed: false, lastAccessed: '2024-01-12' }
];

export const badges: Badge[] = [
  {
    id: '1',
    name: 'First Course Completed',
    description: 'Completed your first course',
    icon: '🎓',
    earned: true,
    earnedDate: '2024-01-10'
  },
  {
    id: '2',
    name: 'Code Warrior',
    description: 'Completed 3 programming courses',
    icon: '⚔️',
    earned: false
  },
  {
    id: '3',
    name: 'Study Streak',
    description: 'Studied for 7 consecutive days',
    icon: '🔥',
    earned: true,
    earnedDate: '2024-01-08'
  },
  {
    id: '4',
    name: 'Community Helper',
    description: 'Helped 10 students in forums',
    icon: '🤝',
    earned: false
  }
];

export const liveSessions: LiveSession[] = [
  {
    id: '1',
    title: 'Getting Started with Web Development',
    instructor: 'Sarah Chen',
    date: '2024-01-20',
    time: '2:00 PM',
    duration: '1 hour',
    description: 'Interactive session covering HTML/CSS basics',
    isUpcoming: true
  },
  {
    id: '2',
    title: 'Career Skills Workshop',
    instructor: 'Michael Rodriguez',
    date: '2024-01-18',
    time: '3:00 PM',
    duration: '45 minutes',
    description: 'Building professional communication skills',
    isUpcoming: false
  },
  {
    id: '3',
    title: 'JavaScript Q&A Session',
    instructor: 'Alex Kim',
    date: '2024-01-22',
    time: '4:00 PM',
    duration: '1.5 hours',
    description: 'Live coding and answering student questions',
    isUpcoming: true
  }
];

export const sampleQuiz: QuizQuestion[] = [
  {
    id: '1',
    question: 'What does HTML stand for?',
    options: [
      'Hypertext Markup Language',
      'Home Tool Markup Language',
      'Hyperlinks and Text Markup Language',
      'Hypertext Machine Language'
    ],
    correctAnswer: 0,
    explanation: 'HTML stands for Hypertext Markup Language, which is the standard markup language for creating web pages.'
  },
  {
    id: '2',
    question: 'Which CSS property is used to change the text color?',
    options: ['text-color', 'font-color', 'color', 'text-style'],
    correctAnswer: 2,
    explanation: 'The "color" property in CSS is used to set the color of text content.'
  }
];