import React, { useState } from 'react';
import { Brain, Code, Zap, Play, Check, X, RotateCcw, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { sampleQuiz } from '../data/mockData';

const Tools = () => {
  const [activeTab, setActiveTab] = useState('quiz');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState<number[]>([]);

  const tools = [
    {
      id: 'quiz',
      name: 'Interactive Quizzes',
      icon: Brain,
      description: 'Test your knowledge with adaptive quizzes',
      color: 'blue'
    },
    {
      id: 'flashcards',
      name: 'Smart Flashcards',
      icon: Zap,
      description: 'Memorize key concepts efficiently',
      color: 'green'
    },
    {
      id: 'playground',
      name: 'Code Playground',
      icon: Code,
      description: 'Practice coding in a safe environment',
      color: 'purple'
    }
  ];

  const flashcards = [
    { front: 'What is HTML?', back: 'Hypertext Markup Language - the standard markup language for creating web pages' },
    { front: 'What does CSS stand for?', back: 'Cascading Style Sheets - used for styling and laying out web pages' },
    { front: 'What is JavaScript?', back: 'A programming language that enables interactive web pages and dynamic content' }
  ];

  const [currentCard, setCurrentCard] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const handleAnswerSubmit = () => {
    if (selectedAnswer === null) return;
    
    const isCorrect = selectedAnswer === sampleQuiz[currentQuestion].correctAnswer;
    if (isCorrect && !answeredQuestions.includes(currentQuestion)) {
      setScore(score + 1);
      setAnsweredQuestions([...answeredQuestions, currentQuestion]);
    }
    setShowResult(true);
  };

  const nextQuestion = () => {
    if (currentQuestion < sampleQuiz.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnsweredQuestions([]);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Interactive Learning Tools</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Enhance your learning with our collection of interactive tools designed to make studying engaging and effective.
          </p>
        </motion.div>

        {/* Tool Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 p-6">
              {tools.map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => setActiveTab(tool.id)}
                  className={`flex items-center space-x-2 py-2 px-4 rounded-lg transition-colors ${
                    activeTab === tool.id
                      ? `bg-${tool.color}-100 text-${tool.color}-700`
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <tool.icon className="h-5 w-5" />
                  <span className="font-medium">{tool.name}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            <AnimatePresence mode="wait">
              {activeTab === 'quiz' && (
                <motion.div
                  key="quiz"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="max-w-2xl mx-auto">
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-2xl font-bold text-gray-800">HTML & CSS Quiz</h3>
                        <div className="flex items-center space-x-4">
                          <span className="text-sm text-gray-600">
                            Question {currentQuestion + 1} of {sampleQuiz.length}
                          </span>
                          <div className="flex items-center space-x-2">
                            <Award className="h-5 w-5 text-yellow-500" />
                            <span className="font-semibold">{score}/{sampleQuiz.length}</span>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all"
                          style={{ width: `${((currentQuestion + 1) / sampleQuiz.length) * 100}%` }}
                        ></div>
                      </div>
                    </div>

                    {currentQuestion < sampleQuiz.length && (
                      <div className="bg-gray-50 rounded-lg p-6">
                        <h4 className="text-lg font-semibold mb-4">{sampleQuiz[currentQuestion].question}</h4>
                        <div className="space-y-3">
                          {sampleQuiz[currentQuestion].options.map((option, index) => (
                            <button
                              key={index}
                              onClick={() => !showResult && setSelectedAnswer(index)}
                              disabled={showResult}
                              className={`w-full text-left p-3 rounded-lg border-2 transition-colors ${
                                showResult
                                  ? index === sampleQuiz[currentQuestion].correctAnswer
                                    ? 'border-green-500 bg-green-50 text-green-700'
                                    : index === selectedAnswer && index !== sampleQuiz[currentQuestion].correctAnswer
                                    ? 'border-red-500 bg-red-50 text-red-700'
                                    : 'border-gray-200 bg-gray-100'
                                  : selectedAnswer === index
                                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                                  : 'border-gray-200 hover:border-gray-300'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span>{option}</span>
                                {showResult && index === sampleQuiz[currentQuestion].correctAnswer && (
                                  <Check className="h-5 w-5 text-green-600" />
                                )}
                                {showResult && index === selectedAnswer && index !== sampleQuiz[currentQuestion].correctAnswer && (
                                  <X className="h-5 w-5 text-red-600" />
                                )}
                              </div>
                            </button>
                          ))}
                        </div>

                        {showResult && (
                          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                            <p className="text-blue-800">{sampleQuiz[currentQuestion].explanation}</p>
                          </div>
                        )}

                        <div className="mt-6 flex justify-between">
                          <button
                            onClick={resetQuiz}
                            className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                          >
                            <RotateCcw className="h-4 w-4" />
                            <span>Reset Quiz</span>
                          </button>
                          
                          {!showResult ? (
                            <button
                              onClick={handleAnswerSubmit}
                              disabled={selectedAnswer === null}
                              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
                            >
                              Submit Answer
                            </button>
                          ) : (
                            <button
                              onClick={nextQuestion}
                              disabled={currentQuestion >= sampleQuiz.length - 1}
                              className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
                            >
                              {currentQuestion >= sampleQuiz.length - 1 ? 'Quiz Complete!' : 'Next Question'}
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {activeTab === 'flashcards' && (
                <motion.div
                  key="flashcards"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="max-w-md mx-auto">
                    <div className="mb-6 text-center">
                      <h3 className="text-2xl font-bold text-gray-800 mb-2">Web Development Basics</h3>
                      <p className="text-gray-600">Card {currentCard + 1} of {flashcards.length}</p>
                    </div>

                    <div 
                      className="relative h-64 cursor-pointer"
                      onClick={() => setIsFlipped(!isFlipped)}
                    >
                      <motion.div
                        className="absolute inset-0 w-full h-full"
                        initial={false}
                        animate={{ rotateY: isFlipped ? 180 : 0 }}
                        transition={{ duration: 0.6 }}
                        style={{ transformStyle: 'preserve-3d' }}
                      >
                        {/* Front */}
                        <div 
                          className="absolute inset-0 w-full h-full bg-blue-600 text-white rounded-lg p-6 flex items-center justify-center text-center shadow-lg"
                          style={{ backfaceVisibility: 'hidden' }}
                        >
                          <div>
                            <h4 className="text-lg font-semibold mb-4">{flashcards[currentCard].front}</h4>
                            <p className="text-blue-200 text-sm">Click to reveal answer</p>
                          </div>
                        </div>

                        {/* Back */}
                        <div 
                          className="absolute inset-0 w-full h-full bg-green-600 text-white rounded-lg p-6 flex items-center justify-center text-center shadow-lg"
                          style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
                        >
                          <div>
                            <p className="text-lg">{flashcards[currentCard].back}</p>
                          </div>
                        </div>
                      </motion.div>
                    </div>

                    <div className="mt-6 flex justify-between">
                      <button
                        onClick={() => {
                          setCurrentCard(Math.max(0, currentCard - 1));
                          setIsFlipped(false);
                        }}
                        disabled={currentCard === 0}
                        className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        Previous
                      </button>
                      <button
                        onClick={() => setIsFlipped(!isFlipped)}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        {isFlipped ? 'Show Question' : 'Show Answer'}
                      </button>
                      <button
                        onClick={() => {
                          setCurrentCard(Math.min(flashcards.length - 1, currentCard + 1));
                          setIsFlipped(false);
                        }}
                        disabled={currentCard === flashcards.length - 1}
                        className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'playground' && (
                <motion.div
                  key="playground"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="max-w-4xl mx-auto">
                    <div className="mb-6 text-center">
                      <h3 className="text-2xl font-bold text-gray-800 mb-2">HTML/CSS Playground</h3>
                      <p className="text-gray-600">Write code and see the results instantly</p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-800 mb-3">HTML</h4>
                        <textarea
                          className="w-full h-48 p-4 border border-gray-300 rounded-lg font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Write your HTML here..."
                          defaultValue="<h1>Hello World!</h1>\n<p>Welcome to the code playground.</p>\n<button>Click me!</button>"
                        ></textarea>
                        
                        <h4 className="font-semibold text-gray-800 mb-3 mt-4">CSS</h4>
                        <textarea
                          className="w-full h-48 p-4 border border-gray-300 rounded-lg font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Write your CSS here..."
                          defaultValue="h1 {\n  color: #3B82F6;\n  text-align: center;\n}\n\nbutton {\n  background: #10B981;\n  color: white;\n  padding: 10px 20px;\n  border: none;\n  border-radius: 5px;\n  cursor: pointer;\n}"
                        ></textarea>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-semibold text-gray-800">Preview</h4>
                          <button className="flex items-center space-x-2 bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition-colors">
                            <Play className="h-4 w-4" />
                            <span>Run Code</span>
                          </button>
                        </div>
                        <div className="w-full h-80 border border-gray-300 rounded-lg bg-white p-4 overflow-auto">
                          <div className="preview-content">
                            <h1 style={{ color: '#3B82F6', textAlign: 'center' }}>Hello World!</h1>
                            <p>Welcome to the code playground.</p>
                            <button style={{ 
                              background: '#10B981', 
                              color: 'white', 
                              padding: '10px 20px', 
                              border: 'none', 
                              borderRadius: '5px', 
                              cursor: 'pointer' 
                            }}>
                              Click me!
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Tools;