import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Award, BookOpen, Clock, Play, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import { courses } from '../data/courses';
import { userProgress, badges } from '../data/mockData';

const Dashboard = () => {
  const enrolledCourses = courses.filter(course => 
    userProgress.some(progress => progress.courseId === course.id)
  );

  const completedCourses = userProgress.filter(progress => progress.completed).length;
  const totalPoints = 2450;
  const currentLevel = Math.floor(totalPoints / 1000) + 1;
  const earnedBadges = badges.filter(badge => badge.earned);

  const recommendedCourses = courses.filter(course => 
    !userProgress.some(progress => progress.courseId === course.id)
  ).slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl p-8 mb-8"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Welcome back, Alex! 👋</h1>
              <p className="text-blue-100">Ready to continue your learning journey?</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">Level {currentLevel}</div>
              <div className="text-blue-200">🔥 {totalPoints} points</div>
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { icon: BookOpen, label: 'Courses Enrolled', value: enrolledCourses.length, color: 'blue' },
            { icon: Award, label: 'Completed', value: completedCourses, color: 'green' },
            { icon: Star, label: 'Badges Earned', value: earnedBadges.length, color: 'yellow' },
            { icon: TrendingUp, label: 'Current Level', value: currentLevel, color: 'purple' }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-sm p-6"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                  <stat.icon className={`h-6 w-6 text-${stat.color}-600`} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Continue Learning */}
            <motion.section
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white rounded-lg shadow-sm"
            >
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">Continue Learning</h2>
              </div>
              <div className="p-6 space-y-4">
                {enrolledCourses.map((course) => {
                  const progress = userProgress.find(p => p.courseId === course.id);
                  return (
                    <div key={course.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <img
                          src={course.image}
                          alt={course.title}
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-800 mb-1">{course.title}</h3>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>{course.instructor.name}</span>
                            <span>•</span>
                            <span>{progress?.progress}% complete</span>
                          </div>
                          <div className="mt-2">
                            <div className="bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full transition-all"
                                style={{ width: `${progress?.progress || 0}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                        <Link
                          to={`/course/${course.id}`}
                          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                        >
                          <Play className="h-4 w-4 mr-1" />
                          Continue
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.section>

            {/* Recommended Courses */}
            <motion.section
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white rounded-lg shadow-sm"
            >
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">Recommended for You</h2>
              </div>
              <div className="p-6">
                <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {recommendedCourses.map((course) => (
                    <div key={course.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <img
                        src={course.image}
                        alt={course.title}
                        className="w-full h-32 rounded-lg object-cover mb-3"
                      />
                      <h3 className="font-semibold text-gray-800 mb-2">{course.title}</h3>
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">{course.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-500">{course.duration}</span>
                        <Link
                          to={`/course/${course.id}`}
                          className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                        >
                          View Course
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.section>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Achievements */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-white rounded-lg shadow-sm"
            >
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-bold text-gray-800">Recent Badges</h3>
              </div>
              <div className="p-6 space-y-4">
                {earnedBadges.map((badge) => (
                  <div key={badge.id} className="flex items-center space-x-3">
                    <div className="text-2xl">{badge.icon}</div>
                    <div>
                      <h4 className="font-medium text-gray-800">{badge.name}</h4>
                      <p className="text-sm text-gray-600">{badge.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Study Streak */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="bg-gradient-to-r from-orange-400 to-red-500 text-white rounded-lg p-6"
            >
              <div className="text-center">
                <div className="text-3xl mb-2">🔥</div>
                <h3 className="text-lg font-bold mb-1">7 Day Streak!</h3>
                <p className="text-orange-100 text-sm">Keep learning to maintain your streak</p>
                <div className="mt-4 bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full w-3/4"></div>
                </div>
                <p className="text-xs text-orange-100 mt-2">3 days until next milestone</p>
              </div>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="bg-white rounded-lg shadow-sm p-6"
            >
              <h3 className="text-lg font-bold text-gray-800 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link
                  to="/tools"
                  className="block w-full text-left bg-blue-50 text-blue-700 p-3 rounded-lg hover:bg-blue-100 transition-colors"
                >
                  Take a Quiz
                </Link>
                <Link
                  to="/community"
                  className="block w-full text-left bg-green-50 text-green-700 p-3 rounded-lg hover:bg-green-100 transition-colors"
                >
                  Visit Community
                </Link>
                <Link
                  to="/live-sessions"
                  className="block w-full text-left bg-purple-50 text-purple-700 p-3 rounded-lg hover:bg-purple-100 transition-colors"
                >
                  Join Live Session
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;