import React, { useState } from 'react';
import { PlusCircle, FileText, BarChart3, Users, Save, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

const TeacherTools = () => {
  const [activeTab, setActiveTab] = useState('quiz-builder');
  const [quizTitle, setQuizTitle] = useState('');
  const [questions, setQuestions] = useState([{
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0
  }]);

  const addQuestion = () => {
    setQuestions([...questions, {
      question: '',
      options: ['', '', '', ''],
      correctAnswer: 0
    }]);
  };

  const updateQuestion = (index: number, field: string, value: any) => {
    const updated = [...questions];
    if (field === 'options') {
      updated[index].options = value;
    } else {
      (updated[index] as any)[field] = value;
    }
    setQuestions(updated);
  };

  const updateOption = (questionIndex: number, optionIndex: number, value: string) => {
    const updated = [...questions];
    updated[questionIndex].options[optionIndex] = value;
    setQuestions(updated);
  };

  const tools = [
    { id: 'quiz-builder', label: 'Quiz Builder', icon: PlusCircle, color: 'blue' },
    { id: 'lesson-planner', label: 'Lesson Planner', icon: FileText, color: 'green' },
    { id: 'analytics', label: 'Student Analytics', icon: BarChart3, color: 'purple' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Teacher Tools</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Create engaging content, track student progress, and manage your teaching materials with our comprehensive toolkit.
          </p>
        </motion.div>

        {/* Navigation */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 p-6">
              {tools.map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => setActiveTab(tool.id)}
                  className={`flex items-center space-x-2 py-2 px-4 rounded-lg transition-colors ${
                    activeTab === tool.id
                      ? `bg-${tool.color}-100 text-${tool.color}-700`
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <tool.icon className="h-5 w-5" />
                  <span className="font-medium">{tool.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'quiz-builder' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="max-w-4xl mx-auto"
              >
                <div className="mb-8">
                  <h2 className="text-2xl font-bold text-gray-800 mb-4">Create New Quiz</h2>
                  <div className="bg-gray-50 rounded-lg p-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Quiz Title
                    </label>
                    <input
                      type="text"
                      value={quizTitle}
                      onChange={(e) => setQuizTitle(e.target.value)}
                      placeholder="Enter quiz title..."
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="space-y-8">
                  {questions.map((question, qIndex) => (
                    <div key={qIndex} className="bg-white border border-gray-200 rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-800">
                          Question {qIndex + 1}
                        </h3>
                        {questions.length > 1 && (
                          <button
                            onClick={() => setQuestions(questions.filter((_, i) => i !== qIndex))}
                            className="text-red-500 hover:text-red-700 text-sm"
                          >
                            Remove
                          </button>
                        )}
                      </div>

                      <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Question Text
                        </label>
                        <textarea
                          value={question.question}
                          onChange={(e) => updateQuestion(qIndex, 'question', e.target.value)}
                          placeholder="Enter your question..."
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                        />
                      </div>

                      <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Answer Options
                        </label>
                        <div className="space-y-3">
                          {question.options.map((option, oIndex) => (
                            <div key={oIndex} className="flex items-center space-x-3">
                              <input
                                type="radio"
                                name={`correct-${qIndex}`}
                                checked={question.correctAnswer === oIndex}
                                onChange={() => updateQuestion(qIndex, 'correctAnswer', oIndex)}
                                className="text-blue-600 focus:ring-blue-500"
                              />
                              <input
                                type="text"
                                value={option}
                                onChange={(e) => updateOption(qIndex, oIndex, e.target.value)}
                                placeholder={`Option ${oIndex + 1}`}
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                            </div>
                          ))}
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          Select the radio button next to the correct answer
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 flex justify-between">
                  <button
                    onClick={addQuestion}
                    className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    <PlusCircle className="h-5 w-5" />
                    <span>Add Question</span>
                  </button>

                  <div className="flex space-x-3">
                    <button className="flex items-center space-x-2 bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                      <Eye className="h-4 w-4" />
                      <span>Preview</span>
                    </button>
                    <button className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                      <Save className="h-4 w-4" />
                      <span>Save Quiz</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'lesson-planner' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="max-w-4xl mx-auto"
              >
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Lesson Planner</h2>
                
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="bg-white border border-gray-200 rounded-lg p-6">
                      <h3 className="font-semibold text-gray-800 mb-4">Lesson Details</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Lesson Title
                          </label>
                          <input
                            type="text"
                            placeholder="Enter lesson title..."
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Duration (minutes)
                          </label>
                          <input
                            type="number"
                            placeholder="60"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Learning Objectives
                          </label>
                          <textarea
                            placeholder="What will students learn?"
                            rows={4}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="bg-white border border-gray-200 rounded-lg p-6">
                      <h3 className="font-semibold text-gray-800 mb-4">Materials Needed</h3>
                      <textarea
                        placeholder="List required materials, tools, or resources..."
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-white border border-gray-200 rounded-lg p-6">
                      <h3 className="font-semibold text-gray-800 mb-4">Lesson Structure</h3>
                      <div className="space-y-4">
                        {[
                          { phase: 'Introduction', duration: '10 min' },
                          { phase: 'Main Content', duration: '35 min' },
                          { phase: 'Practice Activity', duration: '10 min' },
                          { phase: 'Wrap-up', duration: '5 min' }
                        ].map((section, index) => (
                          <div key={index} className="border border-gray-200 rounded p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium text-gray-700">{section.phase}</span>
                              <span className="text-sm text-gray-500">{section.duration}</span>
                            </div>
                            <textarea
                              placeholder="Describe activities and content..."
                              rows={2}
                              className="w-full px-2 py-1 text-sm border border-gray-200 rounded focus:outline-none focus:ring-1 focus:ring-green-500 resize-none"
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white border border-gray-200 rounded-lg p-6">
                      <h3 className="font-semibold text-gray-800 mb-4">Assessment</h3>
                      <textarea
                        placeholder="How will you assess student understanding?"
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-8 flex justify-end space-x-3">
                  <button className="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                    Save Draft
                  </button>
                  <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
                    Save Lesson Plan
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'analytics' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="max-w-6xl mx-auto"
              >
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Student Performance Analytics</h2>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {[
                    { label: 'Total Students', value: '324', change: '+12%', color: 'blue' },
                    { label: 'Average Score', value: '87%', change: '+5%', color: 'green' },
                    { label: 'Completion Rate', value: '94%', change: '+8%', color: 'purple' }
                  ].map((stat, index) => (
                    <div key={index} className="bg-white border border-gray-200 rounded-lg p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                          <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                        </div>
                        <div className={`text-${stat.color}-600 text-sm font-medium`}>
                          {stat.change}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="grid lg:grid-cols-2 gap-8">
                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <h3 className="font-semibold text-gray-800 mb-4">Course Progress Overview</h3>
                    <div className="space-y-4">
                      {[
                        { course: 'HTML & CSS Basics', completed: 89, total: 120 },
                        { course: 'JavaScript Fundamentals', completed: 67, total: 95 },
                        { course: 'Design Thinking', completed: 45, total: 60 }
                      ].map((course, index) => (
                        <div key={index}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-700">{course.course}</span>
                            <span className="text-gray-500">{course.completed}/{course.total}</span>
                          </div>
                          <div className="bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-purple-600 h-2 rounded-full"
                              style={{ width: `${(course.completed / course.total) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <h3 className="font-semibold text-gray-800 mb-4">Recent Activity</h3>
                    <div className="space-y-4">
                      {[
                        { student: 'Emma Wilson', action: 'Completed quiz', course: 'HTML Basics', time: '2 hours ago' },
                        { student: 'James Chen', action: 'Started lesson', course: 'CSS Layout', time: '4 hours ago' },
                        { student: 'Maria Rodriguez', action: 'Posted question', course: 'JavaScript', time: '6 hours ago' }
                      ].map((activity, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                            <Users className="h-4 w-4 text-gray-600" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm text-gray-800">
                              <span className="font-medium">{activity.student}</span> {activity.action}
                            </p>
                            <p className="text-xs text-gray-500">{activity.course} • {activity.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherTools;