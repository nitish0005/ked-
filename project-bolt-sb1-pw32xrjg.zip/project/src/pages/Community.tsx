import React, { useState } from 'react';
import { MessageSquare, Users, TrendingUp, Search, Plus, Heart, MessageCircle, Share2 } from 'lucide-react';
import { motion } from 'framer-motion';

const Community = () => {
  const [activeTab, setActiveTab] = useState('discussions');

  const discussions = [
    {
      id: 1,
      title: 'How to debug JavaScript errors effectively?',
      author: 'Sarah Chen',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100',
      category: 'Programming',
      replies: 15,
      likes: 23,
      timeAgo: '2 hours ago',
      content: 'I\'m struggling with debugging JavaScript errors in my projects. What are your best practices and tools?'
    },
    {
      id: 2,
      title: 'Study group for HTML/CSS beginners',
      author: 'Mike Rodriguez',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100',
      category: 'Study Groups',
      replies: 8,
      likes: 12,
      timeAgo: '4 hours ago',
      content: 'Looking to form a study group for HTML/CSS fundamentals. Anyone interested in joining?'
    },
    {
      id: 3,
      title: 'Tips for staying motivated while learning to code',
      author: 'Alex Kim',
      avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100',
      category: 'Motivation',
      replies: 32,
      likes: 45,
      timeAgo: '1 day ago',
      content: 'Coding can be challenging sometimes. Here are some strategies that helped me stay motivated...'
    }
  ];

  const studyGroups = [
    {
      id: 1,
      name: 'JavaScript Beginners Circle',
      members: 24,
      description: 'Weekly meetups for JavaScript newcomers',
      nextMeeting: 'Tomorrow at 7 PM',
      category: 'Programming'
    },
    {
      id: 2,
      name: 'Design Thinking Workshop',
      members: 18,
      description: 'Collaborative design thinking sessions',
      nextMeeting: 'Friday at 3 PM',
      category: 'Design'
    },
    {
      id: 3,
      name: 'Study Skills Masterclass',
      members: 31,
      description: 'Sharing effective study techniques',
      nextMeeting: 'Monday at 6 PM',
      category: 'Study Skills'
    }
  ];

  const mentors = [
    {
      id: 1,
      name: 'Dr. Emily Watson',
      title: 'Senior Full-Stack Developer',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100',
      expertise: ['JavaScript', 'React', 'Node.js'],
      rating: 4.9,
      sessions: 156
    },
    {
      id: 2,
      name: 'James Thompson',
      title: 'UX Design Lead',
      avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100',
      expertise: ['Design Thinking', 'Figma', 'User Research'],
      rating: 4.8,
      sessions: 89
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Learning Community</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Connect with fellow learners, join study groups, and get help from mentors in our supportive community.
          </p>
        </motion.div>

        {/* Community Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {[
            { icon: Users, label: 'Active Members', value: '12,500+', color: 'blue' },
            { icon: MessageSquare, label: 'Discussions', value: '3,200+', color: 'green' },
            { icon: TrendingUp, label: 'Study Groups', value: '150+', color: 'purple' }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-sm p-6 text-center"
            >
              <div className={`inline-flex items-center justify-center w-12 h-12 bg-${stat.color}-100 text-${stat.color}-600 rounded-lg mb-4`}>
                <stat.icon className="h-6 w-6" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</h3>
              <p className="text-gray-600">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 p-6">
              {[
                { id: 'discussions', label: 'Discussions', icon: MessageSquare },
                { id: 'groups', label: 'Study Groups', icon: Users },
                { id: 'mentors', label: 'Find Mentors', icon: TrendingUp }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-2 px-4 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <tab.icon className="h-5 w-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'discussions' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex-1 max-w-md">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                      <input
                        type="text"
                        placeholder="Search discussions..."
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>New Discussion</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {discussions.map((discussion) => (
                    <div key={discussion.id} className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start space-x-4">
                        <img
                          src={discussion.avatar}
                          alt={discussion.author}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold text-gray-800 hover:text-blue-600 cursor-pointer">
                              {discussion.title}
                            </h3>
                            <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs">
                              {discussion.category}
                            </span>
                          </div>
                          <p className="text-gray-600 mb-3">{discussion.content}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <span>by {discussion.author}</span>
                              <span>•</span>
                              <span>{discussion.timeAgo}</span>
                            </div>
                            <div className="flex items-center space-x-4">
                              <button className="flex items-center space-x-1 text-gray-500 hover:text-red-500 transition-colors">
                                <Heart className="h-4 w-4" />
                                <span>{discussion.likes}</span>
                              </button>
                              <button className="flex items-center space-x-1 text-gray-500 hover:text-blue-500 transition-colors">
                                <MessageCircle className="h-4 w-4" />
                                <span>{discussion.replies}</span>
                              </button>
                              <button className="text-gray-500 hover:text-gray-700 transition-colors">
                                <Share2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'groups' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-800">Study Groups</h2>
                  <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>Create Group</span>
                  </button>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {studyGroups.map((group) => (
                    <div key={group.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                      <div className="mb-4">
                        <h3 className="font-semibold text-gray-800 mb-2">{group.name}</h3>
                        <p className="text-gray-600 text-sm mb-3">{group.description}</p>
                        <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">
                          {group.category}
                        </span>
                      </div>
                      <div className="space-y-2 text-sm text-gray-600 mb-4">
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-2" />
                          <span>{group.members} members</span>
                        </div>
                        <div>
                          <strong>Next meeting:</strong> {group.nextMeeting}
                        </div>
                      </div>
                      <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Join Group
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'mentors' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="mb-6">
                  <h2 className="text-xl font-bold text-gray-800 mb-2">Find Your Mentor</h2>
                  <p className="text-gray-600">Connect with experienced professionals for personalized guidance</p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  {mentors.map((mentor) => (
                    <div key={mentor.id} className="border border-gray-200 rounded-lg p-6">
                      <div className="flex items-start space-x-4 mb-4">
                        <img
                          src={mentor.avatar}
                          alt={mentor.name}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-800 mb-1">{mentor.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{mentor.title}</p>
                          <div className="flex items-center space-x-2 text-sm">
                            <span className="text-yellow-500">★ {mentor.rating}</span>
                            <span className="text-gray-500">•</span>
                            <span className="text-gray-500">{mentor.sessions} sessions</span>
                          </div>
                        </div>
                      </div>
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-700 mb-2">Expertise</h4>
                        <div className="flex flex-wrap gap-2">
                          {mentor.expertise.map((skill) => (
                            <span key={skill} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                      <button className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors">
                        Book Session
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Community;