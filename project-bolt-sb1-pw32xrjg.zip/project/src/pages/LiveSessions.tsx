import React, { useState } from 'react';
import { Calendar, Clock, Users, Video, Play, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import { liveSessions } from '../data/mockData';

const LiveSessions = () => {
  const [activeTab, setActiveTab] = useState('upcoming');

  const upcomingSessions = liveSessions.filter(session => session.isUpcoming);
  const pastSessions = liveSessions.filter(session => !session.isUpcoming);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Live Learning Sessions</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Join interactive live sessions with expert instructors and connect with learners worldwide.
          </p>
        </motion.div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 p-6">
              {[
                { id: 'upcoming', label: 'Upcoming Sessions', icon: Calendar },
                { id: 'library', label: 'Video Library', icon: Video }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-2 px-4 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  <tab.icon className="h-5 w-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'upcoming' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="space-y-6">
                  {upcomingSessions.map((session, index) => (
                    <motion.div
                      key={session.id}
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-6"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="bg-green-500 text-white px-2 py-1 rounded text-xs font-medium">
                              LIVE
                            </span>
                            <span className="text-gray-600 text-sm">Upcoming</span>
                          </div>
                          <h3 className="text-xl font-bold text-gray-800 mb-2">{session.title}</h3>
                          <p className="text-gray-600 mb-4">{session.description}</p>
                          
                          <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <Calendar className="h-4 w-4" />
                              <span>{session.date}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Clock className="h-4 w-4" />
                              <span>{session.time} ({session.duration})</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Users className="h-4 w-4" />
                              <span>Instructor: {session.instructor}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="ml-6">
                          <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                            Join Session
                          </button>
                          <p className="text-xs text-gray-500 mt-2 text-center">Free to attend</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {upcomingSessions.length === 0 && (
                  <div className="text-center py-12">
                    <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No upcoming sessions</h3>
                    <p className="text-gray-500">Check back later for new live sessions</p>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'library' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="mb-6">
                  <h2 className="text-xl font-bold text-gray-800 mb-2">Recorded Sessions</h2>
                  <p className="text-gray-600">Access our library of past live sessions</p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pastSessions.map((session, index) => (
                    <motion.div
                      key={session.id}
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow group"
                    >
                      <div className="relative">
                        <div className="aspect-video bg-gray-900 flex items-center justify-center">
                          <div className="text-white text-center">
                            <Video className="h-8 w-8 mx-auto mb-2" />
                            <p className="text-sm">Recorded Session</p>
                          </div>
                        </div>
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <button className="bg-white/20 backdrop-blur-sm text-white p-3 rounded-full hover:bg-white/30 transition-colors">
                            <Play className="h-6 w-6" />
                          </button>
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                          {session.duration}
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <h3 className="font-semibold text-gray-800 mb-2 group-hover:text-blue-600 transition-colors">
                          {session.title}
                        </h3>
                        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{session.description}</p>
                        
                        <div className="flex items-center justify-between text-sm text-gray-500">
                          <span>{session.instructor}</span>
                          <div className="flex items-center space-x-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span>4.8</span>
                          </div>
                        </div>
                        
                        <button className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                          Watch Recording
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg p-8 text-center"
        >
          <h2 className="text-2xl font-bold mb-4">Want to Host a Session?</h2>
          <p className="text-purple-100 mb-6">
            Share your expertise with our community and help others learn
          </p>
          <button className="bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
            Become an Instructor
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default LiveSessions;