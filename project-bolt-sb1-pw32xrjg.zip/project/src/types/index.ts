export interface Course {
  id: string;
  title: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  description: string;
  fullDescription: string;
  instructor: {
    name: string;
    bio: string;
    avatar: string;
  };
  duration: string;
  modules: string[];
  category: string;
  image: string;
  enrolled: number;
  rating: number;
}

export interface UserProgress {
  courseId: string;
  progress: number;
  completed: boolean;
  lastAccessed: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface LiveSession {
  id: string;
  title: string;
  instructor: string;
  date: string;
  time: string;
  duration: string;
  description: string;
  isUpcoming: boolean;
}